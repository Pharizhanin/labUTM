# Laborator: funcții, metode și importuri pe web
# Student: Vasilev Petru
# Grupa: SI-265
"""Modul reutilizabil pentru inspectarea unui site web.

Funcțiile de aici sunt importate din main.py, la fel cum importăm requests.
"""

from __future__ import annotations

import datetime as dt
import json
import re
import socket
import ssl
import time
from urllib.parse import urljoin, urlparse

import requests

TIMEOUT = 10
DEFAULT_HEADERS = {"User-Agent": "WebLab-VasilevPetru"}


def fetch(url: str, timeout: int = TIMEOUT):
    """Descarcă url cu antetele implicite ale laboratorului și returnează Response."""
    return requests.get(url, timeout=timeout, headers=DEFAULT_HEADERS)


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


def get_title(html: str) -> str:
    """Extrage textul dintre <title> și </title>. Returnează '' dacă lipsește."""
    start_tag = "<title>"
    end_tag = "</title>"
    start = html.find(start_tag)
    end = html.find(end_tag)
    if start == -1 or end == -1 or end < start:
        return ""
    return html[start + len(start_tag):end].strip()


def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea unui antet sau default dacă lipsește."""
    return fetch(url).headers.get(name, default)


def page_exists(url: str) -> bool:
    """True dacă cererea reușește, False la eroare de rețea."""
    try:
        return fetch(url).ok
    except requests.RequestException:
        return False


def check_paths(base: str, paths: list) -> dict:
    """Returnează {path: status_code} pentru o listă de căi relative."""
    results = {}
    for index, path in enumerate(paths):
        if index:
            time.sleep(1)
        url = base.rstrip("/") + path
        try:
            results[path] = fetch(url).status_code
        except requests.RequestException:
            results[path] = 0
    return results


def security_headers(url: str) -> dict:
    """Verifică prezența a cinci antete de securitate."""
    names = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
    ]
    response = fetch(url)
    return {name: name in response.headers for name in names}


def score_headers(results: dict) -> str:
    """Transformă dicționarul de antete într-un scor de forma '3/5'."""
    total = len(results)
    present = sum(1 for value in results.values() if value)
    return f"{present}/{total}"


def fetch_robots(base: str):
    """Returnează textul /robots.txt sau None dacă fișierul lipsește."""
    try:
        response = fetch(base.rstrip("/") + "/robots.txt")
        if not response.ok:
            return None
        if "User-agent" in response.text or "user-agent" in response.text.lower():
            return response.text
        return None
    except requests.RequestException:
        return None


def disallowed_paths(robots_text) -> list:
    """Listează valorile Disallow: din robots.txt. Acceptă și None."""
    if not robots_text:
        return []
    found = []
    for line in robots_text.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith("disallow:"):
            value = stripped.split(":", 1)[1].strip()
            if value:
                found.append(value)
    return found


def extract_links(html: str) -> list:
    """Toate href-urile unice, în ordinea apariției."""
    return list(dict.fromkeys(re.findall(r'href="([^"]+)"', html)))


def split_links(links: list, domain: str) -> tuple:
    """Împarte legăturile în interne și externe după netloc."""
    internal = []
    external = []
    base = f"https://{domain}"
    domain = domain.lower()
    for link in links:
        full = urljoin(base, link)
        netloc = urlparse(full).netloc.lower()
        if not netloc or netloc == domain or netloc.endswith("." + domain):
            internal.append(link)
        else:
            external.append(link)
    return internal, external


def resolve(hostname: str) -> str:
    """Rezolvă hostname-ul la o adresă IPv4."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname: str) -> int:
    """Zile rămase până la expirarea certificatului TLS de pe portul 443."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
    expires = ssl.cert_time_to_seconds(cert["notAfter"])
    now = dt.datetime.now(dt.timezone.utc).timestamp()
    return int((expires - now) // 86400)


def redirect_chain(url: str) -> list:
    """Urmărește redirecționările de la url (de obicei varianta http://)."""
    parsed = urlparse(url)
    http_url = f"http://{parsed.netloc}{parsed.path or '/'}"
    response = requests.get(http_url, timeout=TIMEOUT, headers=DEFAULT_HEADERS)
    steps = [{"status": step.status_code, "url": step.url} for step in response.history]
    steps.append({"status": response.status_code, "url": response.url})
    return steps


def site_report(url: str, json_path: str = "report.json") -> dict:
    """Construiește, afișează și salvează un raport despre site-ul dat.

    Colectează: status, URL final, titlu, IP, redirecționări, scor antete,
    zile certificat, legături interne/externe, căi interzise din robots.txt.
    """
    response = fetch(url)
    parsed = urlparse(response.url)
    hostname = parsed.netloc or urlparse(url).netloc

    time.sleep(1)
    title = get_title(response.text)

    try:
        ip_address = resolve(hostname)
    except socket.gaierror:
        ip_address = "necunoscută"

    time.sleep(1)
    try:
        redirects = redirect_chain(url)
    except requests.RequestException:
        redirects = []

    time.sleep(1)
    headers_result = security_headers(response.url)
    score = score_headers(headers_result)

    try:
        days_left = cert_days_left(hostname)
    except Exception:
        days_left = None

    links = extract_links(response.text)
    internal, external = split_links(links, hostname)

    time.sleep(1)
    robots = fetch_robots(response.url if response.url.startswith("http") else url)
    blocked = disallowed_paths(robots)

    report = {
        "url": url,
        "final_url": response.url,
        "status_code": response.status_code,
        "title": title,
        "ip": ip_address,
        "redirects": redirects,
        "security_headers": headers_result,
        "security_score": score,
        "certificate_days_left": days_left,
        "links_internal": len(internal),
        "links_external": len(external),
        "disallowed_paths": blocked,
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
    }

    redirect_text = "niciuna"
    if len(redirects) > 1:
        hops = [
            f"{redirects[i]['status']} -> {redirects[i + 1]['url']}"
            for i in range(len(redirects) - 1)
        ]
        redirect_text = ", ".join(hops)

    cert_text = "indisponibil"
    if days_left is not None:
        cert_text = f"{days_left} de zile rămase"

    blocked_text = ", ".join(blocked) if blocked else "niciuna"

    print(f"=== Raport site: {url} ===")
    print(f"Cod de stare:      {response.status_code}")
    print(f"URL final:         {response.url}")
    print(f"Titlu:             {title or '(fără titlu)'}")
    print(f"Adresă IP:         {ip_address}")
    print(f"Redirecționări:    {redirect_text}")
    print(f"Scor securitate:   {score}")
    print(f"Certificat:        {cert_text}")
    print(f"Legături:          {len(internal)} interne, {len(external)} externe")
    print(f"Căi interzise:     {blocked_text}")

    with open(json_path, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print(f"Salvat în {json_path}")
    return report


if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
