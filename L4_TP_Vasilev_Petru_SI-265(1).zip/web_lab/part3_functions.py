# Laborator: funcții, metode și importuri pe web
# Student: Vasilev Petru
# Grupa: SI-265

import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


def fetch(url, timeout=TIMEOUT):
    """Descarcă url și returnează obiectul Response.

    Parametrul timeout are valoarea implicită TIMEOUT (10 secunde).
    """
    return requests.get(url, timeout=timeout)


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code


def get_title(html: str) -> str:
    """Extrage textul dintre tag-urile <title> și </title>.

    Nu face nicio operație de rețea — primește HTML-ul gata descărcat.
    Returnează un șir gol dacă titlul lipsește.
    """
    start_tag = "<title>"
    end_tag = "</title>"
    start = html.find(start_tag)
    end = html.find(end_tag)
    if start == -1 or end == -1 or end < start:
        return ""
    start += len(start_tag)
    return html[start:end].strip()


def page_exists(url: str) -> bool:
    """Returnează True dacă cererea reușește, False la orice eroare de rețea."""
    try:
        response = requests.get(url, timeout=TIMEOUT)
        return response.ok
    except requests.RequestException:
        return False


def check_paths(base: str, paths: list) -> dict:
    """Verifică o listă de căi relative și returnează {path: status_code}."""
    results = {}
    for index, path in enumerate(paths):
        if index:
            time.sleep(1)
        url = base.rstrip("/") + path
        try:
            results[path] = requests.get(url, timeout=TIMEOUT).status_code
        except requests.RequestException:
            results[path] = 0
    return results


def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea unui singur antet HTTP sau default dacă lipsește."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.headers.get(name, default)


def security_headers(url: str) -> dict:
    """Verifică prezența a cinci antete de securitate.

    Returnează un dicționar {nume_antet: True/False}.
    """
    names = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
    ]
    response = requests.get(url, timeout=TIMEOUT)
    return {name: name in response.headers for name in names}


def score_headers(results: dict) -> str:
    """Primește rezultatul lui security_headers și returnează un scor 'k/n'."""
    total = len(results)
    present = sum(1 for value in results.values() if value)
    return f"{present}/{total}"


def fetch_robots(base: str):
    """Returnează textul /robots.txt sau None dacă fișierul lipsește."""
    url = base.rstrip("/") + "/robots.txt"
    try:
        response = requests.get(url, timeout=TIMEOUT)
        if response.ok and "text/html" not in response.headers.get("Content-Type", ""):
            return response.text
        # Unele site-uri întorc index.html (200) în loc de robots.txt.
        if response.ok and "User-agent" in response.text:
            return response.text
        return None
    except requests.RequestException:
        return None


def disallowed_paths(robots_text) -> list:
    """Extrage valorile Disallow: din robots.txt. Acceptă și None."""
    if not robots_text:
        return []
    found = []
    for line in robots_text.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith("disallow:"):
            value = stripped.split(":", 1)[1].strip()
            if value:
                found.append(value)
    return found


def response_times(*urls) -> dict:
    """Măsoară durata fiecărei cereri. Acceptă oricâte URL-uri."""
    times = {}
    for index, url in enumerate(urls):
        if index:
            time.sleep(1)
        start = time.perf_counter()
        try:
            requests.get(url, timeout=TIMEOUT)
            times[url] = round(time.perf_counter() - start, 4)
        except requests.RequestException:
            times[url] = None
    return times


def log(message: str, **details) -> None:
    """Afișează mesajul urmat de fiecare detaliu numit."""
    parts = [message]
    for key, value in details.items():
        parts.append(f"{key}={value}")
    print(" | ".join(parts))


if __name__ == "__main__":
    # Exercițiul 21
    resp = fetch(BASE_URL)
    print("Ex.21 fetch status =", resp.status_code)

    # Exercițiul 22
    time.sleep(1)
    print("Ex.22 /           =", get_status(BASE_URL + "/"))
    time.sleep(1)
    print("Ex.22 /robots.txt =", get_status(BASE_URL + "/robots.txt"))
    time.sleep(1)
    print("Ex.22 /sitemap.xml=", get_status(BASE_URL + "/sitemap.xml"))

    # Exercițiul 23
    time.sleep(1)
    print("Ex.23 timeout implicit =", fetch(BASE_URL).status_code)
    time.sleep(1)
    print("Ex.23 timeout=3        =", fetch(BASE_URL, timeout=3).status_code)

    # Exercițiul 24
    print("Ex.24 titlu =", get_title(resp.text))

    # Exercițiul 25
    print("Ex.25 docstring get_title:")
    help(get_title)

    # Exercițiul 26 — adnotările de tip NU opresc programul
    print("Ex.26 apel get_status(123) — type hints nu blochează execuția")
    try:
        print("Ex.26 rezultat =", get_status(123))  # type: ignore
    except Exception as exc:
        print("Ex.26 eroare la rulare (nu la adnotare):", type(exc).__name__, exc)

    # Exercițiul 27
    print("Ex.27 pagina principală există =", page_exists(BASE_URL))
    print(
        "Ex.27 domeniu invalid există =",
        page_exists("https://this-domain-does-not-exist.invalid"),
    )

    # Exercițiul 28
    time.sleep(1)
    paths = check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"])
    print("Ex.28 check_paths =", paths)

    # Exercițiul 29
    time.sleep(1)
    print("Ex.29 Server =", get_header(BASE_URL, name="Server"))

    # Exercițiul 30 + 31
    time.sleep(1)
    sec = security_headers(BASE_URL)
    print("Ex.30 security_headers =", sec)
    print("Ex.31 scor =", score_headers(sec))

    # Exercițiul 32
    time.sleep(1)
    robots = fetch_robots(BASE_URL)
    print("Ex.32 robots.txt (primele 200):")
    print((robots or "")[:200])
    print("Ex.32 Disallow =", disallowed_paths(robots))
    print("Ex.32 Disallow(None) =", disallowed_paths(None))

    # Exercițiul 33
    print(
        "Ex.33 response_times =",
        response_times(BASE_URL, BASE_URL + "/robots.txt"),
    )

    # Exercițiul 34
    log("verificat", url=BASE_URL, status=200)

    # Verificare: print() doar afișează și pierde valoarea; return o trimite
    # apelantului, care o poate salva, testa sau transmite mai departe.
