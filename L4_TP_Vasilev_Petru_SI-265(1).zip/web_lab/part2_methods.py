# Laborator: funcții, metode și importuri pe web
# Student: Vasilev Petru
# Grupa: SI-265

import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# ---------------------------------------------------------------------------
# Exercițiul 9. Elementele de bază ale răspunsului.
# ---------------------------------------------------------------------------
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex.9 status_code =", response.status_code)  # atribut
print("Ex.9 ok          =", response.ok)           # atribut
print("Ex.9 url         =", response.url)          # atribut
print("Ex.9 encoding    =", response.encoding)     # atribut

# ---------------------------------------------------------------------------
# Exercițiul 10. Tratarea erorilor cu o metodă.
# ---------------------------------------------------------------------------
response.raise_for_status()  # metodă — nu aruncă nimic pentru 200
print("Ex.10 pagina principală: raise_for_status() a trecut")

time.sleep(1)
missing = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
try:
    missing.raise_for_status()
    # Site-ul este un SPA: rutele lipsă pot totuși întoarce 200 + index.html.
    print("Ex.10", missing.url, "a întors", missing.status_code,
          "(nu s-a aruncat HTTPError)")
except requests.HTTPError as exc:
    print("Ex.10 pagina nu există (mesaj prietenos):", exc)

# Demonstrăm și cazul real de HTTPError, fără a încălca regulile
# (GET către httpbin este permis).
time.sleep(1)
demo_404 = requests.get(ECHO_URL + "/status/404", timeout=TIMEOUT)
try:
    demo_404.raise_for_status()
except requests.HTTPError:
    print("Ex.10 HTTPError prins pentru", demo_404.url, "-> mesaj: resursa lipsește")

# ---------------------------------------------------------------------------
# Exercițiul 11. Toate antetele.
# ---------------------------------------------------------------------------
print("Ex.11 antete:")
for name, value in response.headers.items():
    print(f"  {name}: {value}")

# ---------------------------------------------------------------------------
# Exercițiul 12. Metode de dicționar.
# ---------------------------------------------------------------------------
print("Ex.12 Server       =", response.headers.get("Server", "lipsește"))
print("Ex.12 Content-Type =", response.headers.get("Content-Type", "lipsește"))
print("Ex.12 content-type =", response.headers.get("content-type", "lipsește"))
# Observație: obiectul CaseInsensitiveDict din requests tratează numele
# antetelor fără a ține cont de majuscule, deci ambele variante funcționează.

# ---------------------------------------------------------------------------
# Exercițiul 13. Înlănțuirea metodelor de șir.
# ---------------------------------------------------------------------------
cyber_count = response.text.lower().count("cyber")
print("Ex.13 cuvântul 'cyber' apare de", cyber_count, "ori")
# .lower() returnează un nou str, iar .count() este o metodă a acelui str.
# De aceea pot fi înlănțuite: fiecare metodă se apelează pe rezultatul precedentei.

# ---------------------------------------------------------------------------
# Exercițiul 14. Găsirea titlului.
# ---------------------------------------------------------------------------
html = response.text
start = html.find("<title>") + len("<title>")
end = html.find("</title>")
title = html[start:end].strip() if end != -1 and start >= len("<title>") else ""
print("Ex.14 titlu =", title)

# ---------------------------------------------------------------------------
# Exercițiul 15. Numărarea liniilor.
# ---------------------------------------------------------------------------
lines = response.text.splitlines()
longest = max(lines, key=len) if lines else ""
print("Ex.15 linii =", len(lines), "| cea mai lungă are", len(longest), "caractere")

# ---------------------------------------------------------------------------
# Exercițiul 16. Verificarea HTTPS.
# ---------------------------------------------------------------------------
if response.url.startswith("https://"):
    print("Ex.16 Conexiune securizată")
else:
    print("Ex.16 Conexiune nesecurizată")

# ---------------------------------------------------------------------------
# Exercițiul 17. Urmărirea redirecționărilor.
# ---------------------------------------------------------------------------
time.sleep(1)
redirected = requests.get("http://cybercor.org", timeout=TIMEOUT)
print("Ex.17 istoric redirecționări:")
for step in redirected.history:
    print(" ", step.status_code, "->", step.url)
print(" Ex.17 URL final:", redirected.url)

# ---------------------------------------------------------------------------
# Exercițiul 18. HEAD versus GET.
# ---------------------------------------------------------------------------
time.sleep(1)
head_resp = requests.head(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
get_resp = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex.18 HEAD content =", len(head_resp.content),
      "| GET content =", len(get_resp.content))
# HEAD cere doar antetele, fără corp, deci content este gol (0 octeți).
# GET aduce și corpul paginii, deci lungimea este mai mare.

# ---------------------------------------------------------------------------
# Exercițiul 19. Cookie-uri.
# ---------------------------------------------------------------------------
if response.cookies:
    for cookie in response.cookies:
        print("Ex.19 cookie:", cookie.name, "secure=", cookie.secure)
else:
    print("Ex.19 Niciun cookie setat")

# ---------------------------------------------------------------------------
# Exercițiul 20. Sesiuni.
# ---------------------------------------------------------------------------
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-VasilevPetru"})
time.sleep(1)
echo = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print("Ex.20 răspuns /headers:")
print(echo.text)
# Confirmăm că antetul personalizat a fost trimis.
if "WebLab-VasilevPetru" in echo.text:
    print("Ex.20 User-Agent personalizat confirmat")

# Verificare: response.text este un ATRIBUT (valoarea e deja calculată /
# stocată pe obiect). response.json() este o METODĂ — trebuie apelată
# cu paranteze ca să parcurgă corpul și să-l transforme în dict/list.
