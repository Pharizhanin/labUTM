# Laborator: funcții, metode și importuri pe web
# Student: Vasilev Petru
# Grupa: SI-265

import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# ---------------------------------------------------------------------------
# Exercițiul 1. Primul import.
# ---------------------------------------------------------------------------
import requests
import urllib.request

print("Ex.1 requests.__version__ =", requests.__version__)
print("Ex.1 urllib.request este din biblioteca standard")

# requests a avut nevoie de pip install pentru că este o bibliotecă EXTERNĂ
# (nu vine instalată odată cu Python). urllib face parte din biblioteca
# STANDARD a Python, deci este disponibil imediat după instalarea interpretorului.

# ---------------------------------------------------------------------------
# Exercițiul 2. Două stiluri de import.
# ---------------------------------------------------------------------------
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex.2 requests.get status =", response.status_code)

from requests import get

time.sleep(1)
response = get(BASE_URL, timeout=TIMEOUT)
print("Ex.2 from requests import get status =", response.status_code)

# Avantaj import requests: se vede clar de unde vine funcția (requests.get),
# evită conflicte de nume cu funcții proprii.
# Avantaj from requests import get: apelul este mai scurt (doar get(...)),
# util când folosiți des aceeași funcție.

# ---------------------------------------------------------------------------
# Exercițiul 3. Alias-uri.
# ---------------------------------------------------------------------------
import requests as rq

time.sleep(1)
response = rq.get(BASE_URL, timeout=TIMEOUT)
print("Ex.3 rq.get status =", response.status_code)

# Un alias ajută când numele modulului e lung (ex. import numpy as np).
# Un alias încurcă citirea când este neobișnuit sau când ascunde un nume
# cunoscut (ex. import requests as r — cititorul trebuie să-și amintească r).

# ---------------------------------------------------------------------------
# Exercițiul 4. Doar biblioteca standard.
# ---------------------------------------------------------------------------
# Cloudflare respinge User-Agent-ul implicit al urllib (Python-urllib/3.x),
# de aceea construim un Request cu un User-Agent propriu.
req = urllib.request.Request(
    BASE_URL,
    headers={"User-Agent": "WebLab-VasilevPetru"},
)
try:
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        status = resp.status
        body = resp.read().decode("utf-8")
except urllib.error.HTTPError as err:
    status = err.status
    body = err.read().decode("utf-8", errors="replace")
print("Ex.4 urllib status =", status)
print("Ex.4 primele 200 caractere:")
print(body[:200])

# ---------------------------------------------------------------------------
# Exercițiul 5. Priviți în interiorul unui modul.
# ---------------------------------------------------------------------------
print("Ex.5 dir(requests) (primele 30 de nume):")
print(dir(requests)[:30])

# Trei nume alese din dir(requests):
# - get        -> funcție (scurtătură către requests.api.get)
# - Session    -> clasă (creează obiecte Session)
# - adapters   -> modul (submodul intern al pachetului requests)
# - codes      -> obiect / lookup pentru coduri HTTP (nu este o funcție)

# ---------------------------------------------------------------------------
# Exercițiul 6. Citiți documentația.
# ---------------------------------------------------------------------------
# help(requests.get) arată parametrul timeout = timpul maxim de așteptare.
time.sleep(1)
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex.6 cerere cu timeout=", TIMEOUT, "status =", response.status_code)

# ---------------------------------------------------------------------------
# Exercițiul 7. Cronometrarea unei cereri.
# ---------------------------------------------------------------------------
time.sleep(1)
t0 = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
t1 = time.perf_counter()
print("Ex.7 durata măsurată local =", round(t1 - t0, 4), "s")
print("Ex.7 response.elapsed     =", response.elapsed)
# response.elapsed măsoară doar timpul până la primirea răspunsului de la
# server. perf_counter include și overhead-ul local (DNS cache, Python).

# ---------------------------------------------------------------------------
# Exercițiul 8. Când un import eșuează.
# ---------------------------------------------------------------------------
try:
    import bs4
    print("Ex.8 modulul bs4 este deja instalat:", bs4.__version__)
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")

# Verificare: un MODUL este un fișier .py; un PACHET este un director cu
# mai multe module (și de obicei __init__.py); o BIBLIOTECĂ este o colecție
# de pachete/module publicată pentru reutilizare (ex. requests).
