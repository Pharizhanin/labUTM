# Laborator: funcții, metode și importuri pe web
# Student: Vasilev Petru
# Grupa: SI-265

import argparse
import csv
import datetime as dt
import time

from webtools import (
    DEFAULT_HEADERS,
    check_paths,
    get_title,
    security_headers,
    site_report,
    fetch,
)

# Ex.45: dacă main.py ar avea o funcție proprie numită get_title, ea AR
# umbri (override) funcția importată din webtools. Apelul get_title() ar
# rula versiunea locală, nu pe cea din modul. De aceea from ... import
# cere atenție la conflictele de nume. Varianta import webtools evită
# problema: webtools.get_title rămâne distinct de get_title local.


def write_paths_csv(base_url: str, filename: str = "report.csv") -> None:
    """Salvează rezultatul lui check_paths în report.csv."""
    paths = ["/", "/robots.txt", "/sitemap.xml"]
    results = check_paths(base_url, paths)
    checked_at = dt.datetime.now().isoformat(timespec="seconds")
    with open(filename, "w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["path", "status", "checked_at"])
        for path, status in results.items():
            writer.writerow([path, status, checked_at])
    print(f"CSV salvat în {filename}: {results}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Raport rapid despre un site web (laborator L4)."
    )
    parser.add_argument(
        "url",
        nargs="?",
        default="https://cybercor.org",
        help="URL-ul site-ului de inspectat",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    url = args.url

    print("DEFAULT_HEADERS =", DEFAULT_HEADERS)
    # Ex.44 — apel prin modul (demonstrat și cu importul selectiv de mai sus)
    page = fetch(url)
    print("Titlu via get_title(fetch(url).text) =", get_title(page.text))
    time.sleep(1)
    print("Antete securitate =", security_headers(url))

    time.sleep(1)
    write_paths_csv(url, "report.csv")
    time.sleep(1)
    site_report(url, "report.json")


if __name__ == "__main__":
    main()
