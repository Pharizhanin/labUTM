# Laborator: funcții, metode și importuri pe web
# Student: Vasilev Petru
# Grupa: SI-265

import csv
import datetime as dt
import hashlib
import json
import re
import socket
import ssl
import time
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


def show_url_parts(url: str) -> dict:
    """Descompune un URL și returnează părțile principale."""
    parts = urlparse(url)
    return {
        "scheme": parts.scheme,
        "netloc": parts.netloc,
        "path": parts.path,
        "query": parts.query,
        "fragment": parts.fragment,
    }


def join_relative_links(base: str, relatives: list) -> list:
    """Transformă legături relative în URL-uri absolute cu urljoin()."""
    return [urljoin(base, rel) for rel in relatives]


def extract_links(html: str) -> list:
    """Returnează toate valorile href, fără duplicate, păstrând ordinea."""
    found = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(found))


def split_links(links: list, domain: str) -> tuple:
    """Împarte legăturile în interne (același domeniu) și externe."""
    internal = []
    external = []
    base = f"https://{domain}"
    for link in links:
        full = urljoin(base, link)
        netloc = urlparse(full).netloc.lower()
        if not netloc or netloc == domain.lower() or netloc.endswith("." + domain.lower()):
            internal.append(link)
        else:
            external.append(link)
    return internal, external


class ImageFinder(HTMLParser):
    """Colectează atributul src al fiecărui tag <img>."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        # HTMLParser apelează această metodă automat la fiecare tag de start.
        if tag.lower() != "img":
            return
        src = dict(attrs).get("src")
        if src:
            self.images.append(src)


def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 a corpului paginii."""
    response = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()


def save_headers_json(url: str, filename: str = "headers.json") -> dict:
    """Salvează antetele într-un fișier JSON și le reîncarcă."""
    response = requests.get(url, timeout=TIMEOUT)
    data = dict(response.headers)
    with open(filename, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=2)
    with open(filename, encoding="utf-8") as file:
        loaded = json.load(file)
    return loaded


def resolve(hostname: str) -> str:
    """Returnează adresa IPv4 a unui hostname."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
    expires = ssl.cert_time_to_seconds(cert["notAfter"])
    now = dt.datetime.now(dt.timezone.utc).timestamp()
    return int((expires - now) // 86400)


if __name__ == "__main__":
    # Exercițiul 35
    parts = show_url_parts("https://cybercor.org/path?x=1#top")
    print("Ex.35 scheme   =", parts["scheme"])
    print("Ex.35 netloc   =", parts["netloc"])
    print("Ex.35 path     =", parts["path"])
    print("Ex.35 query    =", parts["query"])
    print("Ex.35 fragment =", parts["fragment"])

    # Exercițiul 36
    joined = join_relative_links(BASE_URL, ["/about", "contact.html", "../index.html"])
    print("Ex.36 urljoin =", joined)

    # Exercițiul 37
    home = requests.get(BASE_URL, timeout=TIMEOUT)
    links = extract_links(home.text)
    print("Ex.37 legături unice =", links)

    # Exercițiul 38
    internal, external = split_links(links, "cybercor.org")
    print("Ex.38 interne =", internal)
    print("Ex.38 externe =", external)

    # Exercițiul 39 — test pe HTML cunoscut
    test_html = """
<html><body>
<img src="/logo.png" alt="Logo">
<IMG SRC="poza.jpg">
<img alt="imagine fără src">
<img src="https://cdn.example.com/banner.webp" />
<a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""
    finder = ImageFinder()
    finder.feed(test_html)
    print("Ex.39 test images =", finder.images)
    assert finder.images == [
        "/logo.png",
        "poza.jpg",
        "https://cdn.example.com/banner.webp",
    ], "Parserul nu a găsit exact imaginile așteptate"
    print("Testul a trecut!")

    finder_live = ImageFinder()
    finder_live.feed(home.text)
    print(len(finder_live.images), "imagini găsite")
    for src in finder_live.images:
        print(src)
    print("Ex.39 count <img în text =", home.text.lower().count("<img"))
    # handle_starttag este apelată de HTMLParser.feed(), nu de noi direct.

    # Exercițiul 40
    time.sleep(1)
    fp1 = page_fingerprint(BASE_URL)
    time.sleep(1)
    fp2 = page_fingerprint(BASE_URL)
    print("Ex.40 fingerprint 1 =", fp1)
    print("Ex.40 fingerprint 2 =", fp2)
    print("Ex.40 identice     =", fp1 == fp2)
    # Amprentele diferă când se schimbă conținutul paginii (data din HTML,
    # token CSRF, A/B testing) sau când serverul comprimă/modifică răspunsul.

    # Exercițiul 41
    time.sleep(1)
    loaded = save_headers_json(BASE_URL, "headers.json")
    print("Ex.41 Server din JSON =", loaded.get("Server", loaded.get("server")))

    # Exercițiul 42
    print("Ex.42 IP cybercor.org =", resolve("cybercor.org"))

    # Exercițiul 43
    print("Ex.43 zile până la expirarea certificatului =", cert_days_left("cybercor.org"))
