from PIL import Image
from PIL.ExifTags import TAGS


def grade(dms, ref):
    g, m, s = float(dms[0]), float(dms[1]), float(dms[2])
    val = g + m / 60 + s / 3600
    if ref in ["S", "W"]:
        val = -val
    return round(val, 6)


exif = Image.open("probe/foto.jpg")._getexif() or {}
for id, val in exif.items():
    print(TAGS.get(id, id), "=", val)

gps = exif.get(34853, {})
if gps:
    lat = grade(gps[2], gps[1])
    lon = grade(gps[4], gps[3])
    print("Latitudine:", lat)
    print("Longitudine:", lon)
