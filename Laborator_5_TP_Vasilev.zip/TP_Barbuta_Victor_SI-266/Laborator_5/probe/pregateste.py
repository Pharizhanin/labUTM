import io
import base64
import hashlib
import zipfile

import piexif
from PIL import Image

flag = b"FLAG{forensics_e_despre_rabdare}"
open("probe/mesaj.txt", "w").write(base64.b64encode(flag).decode())

cheie = 0x5A
clar = b"Cheia XOR gasita: parola_scurta"
open("probe/xor.bin", "wb").write(bytes(c ^ cheie for c in clar))

parola = "cybersecuritate"
open("probe/hashuri.txt", "w").write(hashlib.md5(parola.encode()).hexdigest() + "\n")
open("probe/wordlist.txt", "w").write("\n".join(["admin", "1234", "password", parola, "qwerty"]))


def dms(x):
    g = int(x)
    m = int((x - g) * 60)
    s = round(((x - g) * 60 - m) * 3600)
    return ((g, 1), (m, 1), (s, 100))


gps = {
    piexif.GPSIFD.GPSLatitudeRef: b"N",
    piexif.GPSIFD.GPSLatitude: dms(47.0105),
    piexif.GPSIFD.GPSLongitudeRef: b"E",
    piexif.GPSIFD.GPSLongitude: dms(28.8638),
}
exif = {"0th": {piexif.ImageIFD.Make: b"Laborator", piexif.ImageIFD.Model: b"TP5"}, "GPS": gps}
Image.new("RGB", (64, 64), (120, 160, 200)).save("probe/foto.jpg", exif=piexif.dump(exif))

buf = io.BytesIO()
Image.new("RGB", (64, 64), (30, 30, 30)).save(buf, "PNG")
arhiva = io.BytesIO()
z = zipfile.ZipFile(arhiva, "w")
z.writestr("secret.txt", "Fisierul ascuns: coordonatele GPS sunt in foto.jpg")
z.close()
open("probe/ascuns.png", "wb").write(buf.getvalue() + b"indiciu: cauta semnatura PK la coada" + arhiva.getvalue())

print("probe generate")
