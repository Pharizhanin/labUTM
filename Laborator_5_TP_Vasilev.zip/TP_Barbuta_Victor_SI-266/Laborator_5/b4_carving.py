import zipfile

date = open("probe/ascuns.png", "rb").read()
i = date.find(b"PK\x03\x04")
if i != -1:
    open("gasit.zip", "wb").write(date[i:])
    print("arhiva extrasa de la octetul", i)

z = zipfile.ZipFile("gasit.zip")
for nume in z.namelist():
    print(nume, "->", z.read(nume).decode())
