import re

date = open("probe/ascuns.png", "rb").read()
for m in re.findall(rb"[ -~]{6,}", date):
    print(m.decode())
