from PIL import Image

img = Image.open("probe/foto.jpg").convert("RGB")
px = list(img.getdata())
mesaj = b"FLAG{ascuns_in_pixeli}\x00"
biti = "".join(f"{x:08b}" for x in mesaj)

nou = []
i = 0
for (r, g, b) in px:
    canale = [r, g, b]
    for j in range(3):
        if i < len(biti):
            canale[j] = (canale[j] & ~1) | int(biti[i])
            i += 1
    nou.append(tuple(canale))

img.putdata(nou)
img.save("stego.png")
print("mesaj ascuns in stego.png, biti folositi:", len(biti))
