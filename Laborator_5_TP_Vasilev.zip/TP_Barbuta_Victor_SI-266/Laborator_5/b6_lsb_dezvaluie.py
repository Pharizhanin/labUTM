from PIL import Image

px = list(Image.open("stego.png").convert("RGB").getdata())
biti = ""
for (r, g, b) in px:
    biti += str(r & 1) + str(g & 1) + str(b & 1)

octeti = bytearray()
for k in range(0, len(biti), 8):
    o = int(biti[k:k + 8], 2)
    if o == 0:
        break
    octeti.append(o)

print(octeti.decode())
