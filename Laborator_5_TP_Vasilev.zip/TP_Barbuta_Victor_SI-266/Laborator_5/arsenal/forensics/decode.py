import re
import json
import base64
import hashlib
import argparse
from urllib.parse import unquote


def ghici_strat(s):
    if re.search(r"%[0-9A-Fa-f]{2}", s):
        return "url"
    if re.fullmatch(r"[0-9a-fA-F]+", s) and len(s) % 2 == 0:
        return "hex"
    if re.fullmatch(r"[A-Za-z0-9+/=]+", s):
        return "base64"
    return "necunoscut"


def desfa(s):
    strat = ghici_strat(s)
    if strat == "base64":
        return strat, base64.b64decode(s)
    if strat == "hex":
        return strat, bytes.fromhex(s)
    if strat == "url":
        return strat, unquote(s).encode()
    return strat, s.encode()


def citibil(b):
    return all(32 <= c < 127 for c in b)


def desfa_straturi(val):
    strat, b = desfa(val)
    for _ in range(8):
        if citibil(b):
            break
        val = b.decode()
        strat, b = desfa(val)
    return strat, b


def scor_text(b):
    return sum(c == 32 or 65 <= c <= 122 for c in b)


def sparge_xor(cale):
    date = open(cale, "rb").read()
    candidati = []
    for k in range(256):
        clar = bytes(b ^ k for b in date)
        if citibil(clar):
            candidati.append((k, clar))
    candidati.sort(key=lambda x: scor_text(x[1]), reverse=True)
    if candidati:
        k, clar = candidati[0]
        return k, clar.decode()
    return None, None


def sparge_hash(cale_hash, cale_wordlist):
    tinta = open(cale_hash).readline().strip()
    algoritm = {32: "md5", 40: "sha1", 64: "sha256"}.get(len(tinta))
    for cuv in open(cale_wordlist, encoding="latin1"):
        cuv = cuv.strip()
        if hashlib.new(algoritm, cuv.encode()).hexdigest() == tinta:
            return algoritm, cuv
    return algoritm, None


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("intrare")
    p.add_argument("--fisier", action="store_true")
    a = p.parse_args()
    if a.fisier:
        s = open(a.intrare, "rb").read().decode()
    else:
        s = a.intrare
    strat, rezultat = desfa_straturi(s)
    fisa = {"strat": strat, "rezultat": rezultat.decode(errors="replace")}
    with open("arsenal/forensics/fisa.json", "w", encoding="utf-8") as f:
        json.dump(fisa, f, ensure_ascii=False, indent=2)
    print(strat, rezultat)
